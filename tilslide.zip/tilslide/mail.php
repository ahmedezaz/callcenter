
//Created by EZAZ on 31/12/2017.

<?php
$f_name = $_POST['f_name'];
$company = $_POST['company'];
$phone = $_POST['phone'];
$email = $_POST['email'];
$postcode = $_POST['postcode'];
$utility = $_POST['utility'];
$annual = $_POST['annual'];
$message = $_POST['message'];
$formcontent=" company: $company \n phone: $phone \n email: $email \n postcode: $postcode \n utility: $utility \n current annual spend: $annual \n Message: $message";
$recipient = "test@iepbd.com, test2@iepbd.com, test3@iepbd.com, test4@iepbd.com, test5@iepbd.com";
$mailheader = "From: $email \r\n";
mail($recipient, $f_name, $formcontent, $mailheader) or die("Error");
header("location: success.html")
?>